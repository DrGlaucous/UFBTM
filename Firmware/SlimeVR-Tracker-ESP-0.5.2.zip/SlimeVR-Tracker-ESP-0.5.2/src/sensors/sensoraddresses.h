// those variables are used as "supplement" to base IMU address coming directly from IMU
// driver they are remaining to keep backward compatibility with old style of defines.h

#define PRIMARY_IMU_ADDRESS_ONE 0
#define PRIMARY_IMU_ADDRESS_TWO 1
#define SECONDARY_IMU_ADDRESS_ONE 0
#define SECONDARY_IMU_ADDRESS_TWO 1
